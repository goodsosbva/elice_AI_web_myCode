const { Router } = require("express");
const router = Router();
const { Daily } = require("./../../models");
const { User } = require("./../../models");

//일기장 생성
//http://localhost:8080/daily/ 
router.post("/", async (req, res, next) => {
    console.log(req.body);
    let { title, content, url, email } = req.body;

    try {

        const authData = await User.findOne({ email });

        await Daily.create({
            title,
            content,
            url,
            author: authData
        })

        res.json({
            status: true,
            message: "일기장을 생성하였습니다."
        })

    } catch (e) {
        next(e);
    }

})


module.exports = router;