# 서버에 nginx 설치하기

## nginx 설치하기

---

```jsx
apt update
apt upgrade
apt install nginx
service start nginx
service nginx status
```

*무조건 우분투 버전이 16버전 이어야 합니다!!*

우분투 18버전 nginx 설치하기 → [https://velog.io/@byjihye/ubuntu2](https://velog.io/@byjihye/ubuntu2)

nginx 설치가 완료된 후, service nginx status 를 입력하고 난 뒤, active 상태가 되어 있어야 합니다!

## 참고자료

---

[https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwiRy8in0OH6AhXBAYgKHSkgCh0QFnoECBUQAQ&url=https%3A%2F%2Ft-okk.tistory.com%2F154&usg=AOvVaw0xg_PzSkEMaBdzb6t_CXxC](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&ved=2ahUKEwiRy8in0OH6AhXBAYgKHSkgCh0QFnoECBUQAQ&url=https%3A%2F%2Ft-okk.tistory.com%2F154&usg=AOvVaw0xg_PzSkEMaBdzb6t_CXxC)