const name = "elice";
const age = 5;
const nationality = "korea";

module.exports = {
    name,
    age,
    nationality,
};